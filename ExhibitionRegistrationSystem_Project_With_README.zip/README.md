
# 🎓 Exhibition Registration System – Victoria University

This Java-based desktop application was developed for Victoria University's first annual **Innovation and Technology Exhibition**. It provides a complete **GUI + Database integration** system for managing student exhibitor registrations.

---

## 📌 Project Overview

The Exhibition Registration System is designed to:

- Digitize manual registration processes
- Prevent duplicate entries
- Provide quick retrieval and management of exhibitor data
- Integrate with a **Microsoft Access** database using **UCanAccess JDBC Driver**

---

## 🚀 Features

- ✅ Java Swing-based **Graphical User Interface**
- ✅ Full **CRUD** functionality (Create, Read, Update, Delete)
- ✅ Image upload and preview using `JFileChooser`
- ✅ Database integration with **MS Access (.accdb)** using `UCanAccess`
- ✅ Input validation (empty fields, valid email format)
- ✅ Exception handling with secure `PreparedStatement` queries

---

## 🧾 Database Schema

**Table Name:** `Participants`

| Field Name       | Data Type | Description                     |
|------------------|-----------|---------------------------------|
| RegistrationID   | Text      | Unique ID for the participant  |
| StudentName      | Text      | Full name of the student       |
| Faculty          | Text      | Faculty/Department             |
| ProjectTitle     | Text      | Title of the project           |
| ContactNumber    | Text      | Phone number                   |
| EmailAddress     | Text      | Email address                  |
| ImagePath        | Text      | Path to prototype image        |

---

## 🛠️ How to Run the Project

1. **Install Requirements**
   - Java JDK (8 or later)
   - UCanAccess JDBC Driver: [https://ucanaccess.sourceforge.net](https://ucanaccess.sourceforge.net)
   - Microsoft Access (.accdb) file named `VUE_Exhibition.accdb`

2. **Project Structure**
   ```
   ExhibitionRegistrationSystem/
   ├── DBConnection.java
   ├── RegistrationForm.java
   ├── VUE_Exhibition.accdb
   └── README.md
   ```

3. **Compile and Run**
   ```bash
   javac DBConnection.java RegistrationForm.java
   java RegistrationForm
   ```

---

## 🧪 Sample Data

The `Participants` table is pre-populated with at least 5 sample entries in the `.accdb` file. These can be viewed via the GUI after launching the application.

---

## 📸 Screenshots

GUI screenshots and outputs are included in the documentation:  
📄 `ExhibitionRegistrationSystem_Documentation.docx`

---

## 🧹 Input Validation

- **Empty field check** for all mandatory inputs
- **Regex validation** for email format (`\S+@\S+\.\S+`)
- **Exception handling** for SQL errors and invalid file selections

---

## 📤 Submission Contents

- ✅ `DBConnection.java`
- ✅ `RegistrationForm.java`
- ✅ `VUE_Exhibition.accdb` (Access database file)
- ✅ `README.md` (this file)
- ✅ `ExhibitionRegistrationSystem_Documentation.docx` (screenshots + description)

---

## 👨‍💻 Author

Prepared for the Faculty of Science and Technology – Victoria University  
Developed as part of the Innovation and Technology Exhibition case study.
